/*
 Watermelon With Me
 Boot file for JSB
 */

// JS Bindings constants
require("jsb.js");

// resource file
require('resources-jsb.js');

// Level file
require('levels.js');

// game file
require('watermelon_with_me.js');
