var s_coinsPlist = 'res/CCB/coins.plist';
var s_coinsAnimation = 'res/coins_animation.plist';
var s_parallax = 'res/single_files/Parallax.png';
var s_carSmoke = 'res/car_smoke.plist';
var s_HUD = "res/CCB/HUD.ccbi";

var s_Abadi40HDFNT = "res/CCB/Abadi40-hd.fnt";
var s_Abadi40HDPNG = "res/CCB/Abadi40-hd.png";

var s_Abadi40IPADFNT = "res/CCB/Abadi40-ipad.fnt";
var s_Abadi40IPADPNG = "res/CCB/Abadi40-ipad.png";

var s_Abadi40FNT = "res/CCB/Abadi40.fnt";
var s_Abadi40PNG = "res/CCB/Abadi40.png";


var s_Gas40FNT = "res/CCB/Gas40.fnt";
var s_Gas40PNG = "res/CCB/Gas40.png";

var s_Gas40HDFNT = "res/CCB/Gas40-hd.fnt";
var s_Gas40HDPNG = "res/CCB/Gas40-hd.png";

var s_Gas40IPADFNT = "res/CCB/Gas40-ipad.fnt";
var s_Gas40IPADPNG = "res/CCB/Gas40-ipad.png";


var s_Konqa32FNT = "res/CCB/konqa32.fnt";
var s_Konqa32PNG = "res/CCB/konqa32.PNG";

var s_Konqa32HDFNT = "res/CCB/konqa32-hd.fnt";
var s_Konqa32HDPNG = "res/CCB/konqa32-hd.PNG";

var s_Konqa32IPADFNT = "res/CCB/konqa32-ipad.fnt";
var s_Konqa32IPADPNG = "res/CCB/konqa32-ipad.PNG";

var s_GameOverWAV = "res/sound/GameOver.mp3";
var PickupCointWAV = "res/sound/pickup_coin.mp3";
var s_LevelComplete = "res/sound/LevelComplete.mp3";
var s_game_music = "res/sound/game-music.mp3";


var s_body = "res/body.png";
var s_head = "res/head3.png";

var s_MainMenu = "res/CCB/MainMenu.ccbi";
var s_About = "res/CCB/About.ccbi";
