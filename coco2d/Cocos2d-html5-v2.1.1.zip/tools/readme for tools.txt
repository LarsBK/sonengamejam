Compliler:

Default compliler is goole closure compiler. Please install Ant and Jre to build.
The shell files and Closure Compiler which Ant needs are provided in tools folder and cocos2d folder.

Reference wiki: www.cocos2d-x.org/projects/cocos2d-x/wiki/Closure_Compiler